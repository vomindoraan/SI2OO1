#pragma once

class Element {
public:
	virtual double 
		icina() const = 0;
};